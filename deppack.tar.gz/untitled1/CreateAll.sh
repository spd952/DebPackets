#!/bin/bash
set -e

# Параметры
PACKAGE_NAME="untitled1"
VERSION="1.0.0"
ARCH="amd64"
MAINTAINER="Your Name <your.email@example.com>"
DESCRIPTION="Program for finding maximum value in array"

# Пути
BUILD_DIR="build"                 # где лежит скомпилированный бинарник
BINARY_PATH="$BUILD_DIR/untitled1"
DEB_ROOT="deb_root"               # временная папка для сборки пакета

# Проверка бинарника
if [ ! -f "$BINARY_PATH" ]; then
    echo "Error: binary not found. Run 'cmake --build build' first."
    exit 1
fi

# Создание структуры пакета
rm -rf "$DEB_ROOT"
mkdir -p "$DEB_ROOT/usr/local/bin"
mkdir -p "$DEB_ROOT/DEBIAN"

# Копирование программы
cp "$BINARY_PATH" "$DEB_ROOT/usr/local/bin/"
chmod 755 "$DEB_ROOT/usr/local/bin/untitled1"

# Создание control-файла
cat > "$DEB_ROOT/DEBIAN/control" <<EOF
Package: $PACKAGE_NAME
Version: $VERSION
Section: utils
Priority: optional
Architecture: $ARCH
Depends: libc6, libstdc++6
Maintainer: $MAINTAINER
Description: $DESCRIPTION
 This program reads an array of integers and outputs the maximum value.
 Built with CMake and packaged with dpkg-deb.
EOF

# Сборка .deb пакета
dpkg-deb --build "$DEB_ROOT" "${PACKAGE_NAME}_${VERSION}_${ARCH}.deb"

echo "✅ Package created: ${PACKAGE_NAME}_${VERSION}_${ARCH}.deb"

# Очистка временной папки (опционально)
rm -rf "$DEB_ROOT"
